var hinweis = document.createElement("p");

hinweis.innerHTML = '<h4>Hinweis:</h4> Einige der "unbekannt" Anmeldungen können vom Notification Manager des iServ Clients sein.'

document.querySelector("#content > div:nth-child(2) > div > div.page-content.inset > div > div > div:nth-child(2) > div.panel-footer.pt.clearfix").appendChild(hinweis);