let state = false;

chrome.tabs.insertCSS(null, { file: "dm.css" });
