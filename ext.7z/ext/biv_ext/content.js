
document.querySelector("#topbar > div.topbar-header > span").innerHTML += " - Better iServ"