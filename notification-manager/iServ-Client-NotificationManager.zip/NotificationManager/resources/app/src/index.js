const { app, BrowserWindow, Notification, BrowserView, Menu, Tray, session, nativeTheme, net, ClientRequest} = require('electron')
const fs = require('fs');


let domain = ""
let icon = __dirname + "/iserv_logo.png"


function runApp () { 



  let info = 'https://' + domain + '/iserv/infodisplay/index'
  let mail = 'https://' + domain + '/iserv/mail'
  let exer = 'https://' + domain + '/iserv/exercise'
  let file = 'https://' + domain + '/iserv/file'
  let cal = 'https://' + domain + '/iserv/calendar'
  let address = 'https://' + domain + '/iserv/addressbook/personal'
  let forum = 'https://' + domain + '/iserv/forums'
  let mess = 'https://' + domain + '/iserv/messenger'
  let news = 'https://' + domain + '/iserv/news'


  const win = new BrowserWindow({
    width: 400,
    height: 200,
    webPreferences: {
      nodeIntegration: true
    },
    frame: false,
    transparent: true,
    menu: false
  });

  win.setMenu(null)
  win.setTitle("iServClientNotificationManager")
  win.hide();

  tray = new Tray(icon)
  const contextMenu = Menu.buildFromTemplate([
    { label: 'Client öffnen', click: function (event) {

    }},
    { label: 'Beenden', click: function (event) {
      app.exit()

    }}
  ])
  tray.setContextMenu(contextMenu)
  tray.setTitle("iServ-Client: Notification Manager")
  tray.tooltip("iServ-Client: Notification Manager")
  tray.on('click', function () {
    win.show()
  })
}

app.whenReady().then(() => {
  runApp()
})












